
export default function Contact() {
  return <h1>İletişim Sayfası</h1>;
}
