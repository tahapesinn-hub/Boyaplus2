
export default function Products() {
  return <h1>Ürünler Sayfası</h1>;
}
