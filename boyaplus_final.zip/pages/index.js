
export default function Home() {
  return <h1>Boyaplus Ana Sayfa</h1>;
}
