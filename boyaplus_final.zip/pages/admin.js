
export default function Admin() {
  return <h1>Admin Paneli (Parola korumalı)</h1>;
}
